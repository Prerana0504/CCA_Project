import tenseal as ts

# Step 1: Load the context (with secret key) for decryption
with open("context_with_secret.bin", "rb") as f:
    context = ts.context_from(f.read())

# Step 2: Load the encrypted result
with open("encrypted_result.bin", "rb") as f:
    encrypted_result = ts.ckks_vector_from(context, f.read())

# Step 3: Decrypt the result
decrypted_result = encrypted_result.decrypt()

# Step 4: Print the decrypted result
print("Decrypted result:", decrypted_result)