import tenseal as ts
import numpy as np

# Step 1: Create a CKKS context with a secret key
context = ts.context(ts.SCHEME_TYPE.CKKS, poly_modulus_degree=8192, coeff_mod_bit_sizes=[60, 40, 40, 60])
context.global_scale = 2**40  # Set scale for encryption

# Step 2: Save the context (with both secret and public key) to a file
with open("context_with_secret.bin", "wb") as f:
    f.write(context.serialize(save_public_key=True, save_secret_key=True))

# Save only the public context (without secret key) for use on the cloud
with open("public_context.bin", "wb") as f:
    f.write(context.serialize(save_public_key=True, save_secret_key=False))

# Step 3: Create a small dataset
data = np.array([1.1, 2.2, 3.3, 4.4])  # Example dataset

# Step 4: Encrypt the dataset using the CKKS scheme
encrypted_data = ts.ckks_vector(context, data)

# Step 5: Save the encrypted data to a file
with open("encrypted_data.bin", "wb") as f:
    f.write(encrypted_data.serialize())

print("Encryption completed and saved as 'encrypted_data.bin'.")