import tenseal as ts

# Step 1: Load the public context (without secret key)
with open("public_context.bin", "rb") as f:
    context = ts.context_from(f.read())

# Step 2: Load the encrypted dataset
with open("encrypted_data.bin", "rb") as f:
    encrypted_data = ts.ckks_vector_from(context, f.read())

# Step 3: Perform operations on encrypted data (addition and multiplication)
encrypted_result = encrypted_data + encrypted_data  # Element-wise addition
encrypted_result *= 2  # Multiply all elements by 2

# Step 4: Save the encrypted result to a file
with open("encrypted_result.bin", "wb") as f:
    f.write(encrypted_result.serialize())

print("Operations completed and saved to 'encrypted_result.bin'.")